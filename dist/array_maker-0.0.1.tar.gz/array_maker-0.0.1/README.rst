====================================================
array_maker: takes an array and covert it to arrays of arrays
====================================================


input: array of records

output: batches of input records in array format, arrays of input array

spec of output: 

1. each batch is of max size 5mb

2. each record in batch is of max size 1mb, larger should be discarded

3. each batch contains max 500 records



input = ['record1', 'record2', 'record3', ...]

output = [['record1', 'record2'], ['record3'], ['record4',... 'record{n}']]


if sample.txt contains ['a','b']

>>> import array_maker

>>> array_maker.bake_batch('${path_to_sample}/sample.txt')
[['a', 'b']]

more test samples located in /samples

>>> import array_maker
>>> path = '/Users/maryam/Desktop/sample/sample_string.txt'
>>> sample = array_maker.sample_reader(path)
>>> sample_bacthes = array_maker.bake_batch(path)

>>> len(sample)
100
>>> len(sample_bacthes)
9
